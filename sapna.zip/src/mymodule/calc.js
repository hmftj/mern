/* export function Fibb() {
  
    let a = 0, b = 1;
    const result = [];
  
    for (let i = 0; i < 12; i++) {
      result.push(a);
      [a, b] = [b, a + b];
    }
  
    return (result);
  } */





export function Plus(a,b)
{   
    var a =99;
    var b = 100;

    return(a+b);
};


export function Minus(d,c)
{
    
    var c=24 , d =45;

    return(d-c);


};