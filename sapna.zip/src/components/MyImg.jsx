 function MyImg(){
    return( <div>
      
        
        <img
        src='https://hmftj.com/images/logo.png'
        alt='HMFTJ'></img>
       </div> );
};

export default MyImg;