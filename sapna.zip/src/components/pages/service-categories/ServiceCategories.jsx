import React from 'react';
import './ServiceCategories.scss';

const ServiceCategories = () => {

  return (
    <div className="hello">Hello Categories</div>
  );
};

export default ServiceCategories;