import React from 'react';
import './OrdersRecord.scss';

const OrdersRecord = () => {

  return (
    <div className="hello">Hello Record</div>
  );
};

export default OrdersRecord;