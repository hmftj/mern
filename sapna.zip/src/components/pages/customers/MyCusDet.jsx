import React, { useEffect, useState, useRef } from "react";
import { Spin, Table, Typography } from "antd";
import axios from "axios";

const { Title } = Typography;

const MyCusDet = () => {
  const [allCountries, setAllCountries] = useState([]);
  const [displayed, setDisplayed] = useState([]);
  const [loading, setLoading] = useState(false);
  const [page, setPage] = useState(1);
  const tableContainerRef = useRef(null);
  const pageSize = 10;

  const fetchCountries = async () => {
    setLoading(true);
    try {
      const { data } = await axios.get("https://restcountries.com/v3.1/all");
      const formatted = data
        .map((c) => ({
          key: c.name.common,
          label: c.name.common,
          capital: c.capital?.[0] || "N/A",
          population: c.population,
          region: c.region,
          flag: c.flags?.png,
        }))
        .sort((a, b) => a.label.localeCompare(b.label));

      setAllCountries(formatted);
      setDisplayed(formatted.slice(0, pageSize));
    } catch (error) {
      console.error("Error fetching countries:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCountries();
  }, []);

  const handleScroll = () => {
    const container = tableContainerRef.current;
    if (!container) return;

    const { scrollTop, scrollHeight, clientHeight } = container;
    if (scrollTop + clientHeight >= scrollHeight - 10 && !loading) {
      const nextPage = page + 1;
      const nextItems = allCountries.slice(0, nextPage * pageSize);
      setDisplayed(nextItems);
      setPage(nextPage);
    }
  };

  const columns = [
    { title: "Country", dataIndex: "label", key: "label" },
    { title: "Capital", dataIndex: "capital", key: "capital" },
    { title: "Population", dataIndex: "population", key: "population" },
    { title: "Region", dataIndex: "region", key: "region" },
    {
      title: "Flag",
      dataIndex: "flag",
      key: "flag",
      render: (url) => <img src={url} alt="flag" width="40" />,
    },
  ];

  return (
    <div style={{ padding: 24 }}>
      <Title level={4}>All Countries (Scroll to Load More)</Title>

      <div
        ref={tableContainerRef}
        onScroll={handleScroll}
        style={{ maxHeight: 500, overflow: "auto", border: "1px solid #eee", padding: 8 }}
      >
        <Table
          dataSource={displayed}
          columns={columns}
          pagination={false}
          rowKey="label"
        />
        {loading && (
          <div style={{ textAlign: "center", padding: 8 }}>
            <Spin />
          </div>
        )}
      </div>
    </div>
  );
};

export default MyCusDet;
