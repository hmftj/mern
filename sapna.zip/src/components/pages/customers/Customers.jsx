import React from 'react';
import './Customers.scss';
import MyCusDet from './MyCusDet';


const Customers = () => {

  return (
    <>


<MyCusDet></MyCusDet>

    </>
  );
};

export default Customers;