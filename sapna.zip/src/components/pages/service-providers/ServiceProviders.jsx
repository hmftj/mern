import React from 'react';
import './ServiceProviders.scss';

const ServiceProviders = () => {

  return (
    <div className="hello">Hello Service Provider</div>
  );
};

export default ServiceProviders;