import React from 'react';
import * as FaIcons from 'react-icons/fa';
import './Home.scss';
import CustomTable from './../../common/custom-table/CustomTable';

const columns = [
  {
    title: 'Name',
    dataIndex: 'name',
    key: 'name'
  },
  {
    title: 'Email',
    dataIndex: 'email',
    key: 'email'
  },
  {
    title: 'Phone',
    dataIndex: 'phone',
    key: 'phone'
  },
  {
    title: 'Age',
    dataIndex: 'age',
    key: 'age'
  },
  {
    title: 'City',
    dataIndex: 'city',
    key: 'city'
  }
];

const data = [
  {
    key: '1',
    name: 'Alice',
    email: 'alice@test.com',
    phone: '0900-78601',
    age: 25,
    city: 'New York'
  },
  {
    key: '2',
    name: 'Bob',
    email: 'bob@test.com',
    phone: '0900-78601',
    age: 30,
    city: 'London'
  },
  {
    key: '3',
    name: 'Charlie',
    email: 'charlie@test.com',
    phone: '0900-78601',
    age: 28,
    city: 'Paris'
  }
];

const Home = () => {

  return (
    <div className="home-container">
      <div className="dashboard">
        <div className="heading">Dashboard</div>
        <div className="cards">
          <div className="card">
            <div className="icon"><FaIcons.FaUserCog /></div>
            <div className="text">Service providers</div>
          </div>
          <div className="card">
            <div className="icon"><FaIcons.FaUsers /></div>
            <div className="text">Active Customers</div>
          </div>
          <div className="card">
            <div className="icon"><FaIcons.FaClipboardList /></div>
            <div className="text">Total Orders</div>
          </div>
        </div>
      </div>
      <div className="table-details">
        <div className="heading">Customers</div>
        <CustomTable columns={columns} dataSource={data} loading={false} />
      </div>
      <div className="table-details">
        <div className="heading">Orders</div>
        <CustomTable columns={columns} dataSource={data} loading={false} />
      </div>
    </div>
  );
};

export default Home;